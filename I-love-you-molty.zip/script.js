const audio = document.getElementById("bgm");
const replay = document.getElementById("replayBtn");
if (replay) {
  replay.addEventListener("click", () => {
    audio.currentTime = 0;
    audio.play();
  });
}
window.onload = () => { if (audio) audio.play(); };
